# the-final-cl-test

This repo contains the necessary information to solve the "now-get-to-work" exercice of the 01-edu organization
