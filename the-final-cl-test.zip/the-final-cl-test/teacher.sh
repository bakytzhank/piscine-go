#!/bin/bash
# teacher file should be in the same directory with mystery folder

# Input file with clues
report_file="mystery/crimescene"

# Output file with names from clues
witness_names="names.txt"

# Input file with all people
people_file="mystery/people"

# Output file for matching lines
matching_file="matching_people.txt"

# Search for lines containing "CLUE" and extract names
grep -i "CLUE" "$report_file" | grep -oE '\w+s [A-Z][a-z]+' | awk '{print $2}' > "$witness_names"

# Loop through each name in names.txt
while IFS= read -r name; do
  # Use grep to find lines containing the name in people.txt
  grep -i "$name" "$people_file" >> "$match_file"
done < "$witness_names"

# Output file for formatted street names
output_file="formatted_street_names.txt"

# Process each line in the input file
while IFS= read -r line; do
  # Extract the street name
  street_name=$(echo "$line" | awk -F', line ' '{gsub(/ /, "_", $1); print $1}')
  
  # Extract the line number
  line_number=$(echo "$line" | awk -F', line ' '{print $2}')
  
  # Format and store the street name and line number in the output file
  echo "Street Name: $street_name, Line Number: $line_number" >> "$output_file"
done < "$matching_file"

  head -n 40 streets/Hart_Place | tail -n 1